//
//  WebServices.swift
//  APISqlite
//
//  Created by Drish on 08/09/20.
//  Copyright © 2020 Drish. All rights reserved.
//

import UIKit

class WebServices: NSObject {
    //CreateAccount
         func getEmployees(obj: EmployeeModal, _ completionHandler: @escaping((_ response: EmployeeModal?,_ error: Error?, _ success: Bool, _ statusCode : Int) -> Void))
            {
                let url = "http://localhost:3000/employees"
            do{
                CommunicationManager().callApiByGetMethod(urlStr: url, { (response, statusCode) in
                
                if let dict = self.convertIntoDictionary(responseData: response)
                {
                    print((dict as AnyObject).count)
                   // let userObj = EmployeeModal(fromDictionary:  dict as! [String : Any])
                    let userObj = EmployeeModal(fromDictionary:  dict )
                    completionHandler(userObj,nil,true ,statusCode )
                    }
                }, {
                    (error, statusCode) in
                    completionHandler(nil,error,false ,statusCode )
                   
                    print()
                })
                
            }
            catch
            {
                print("in catch..")
            }
         }


    func convertIntoDictionary(responseData: Data?) -> NSArray? {
        if responseData != nil {
            do {

                return try JSONSerialization.jsonObject(with: responseData!, options: .allowFragments) as! NSArray 
            }catch {
                print(error.localizedDescription)
            }
        }
        return nil
    }
}
