//
//  CommunicationManager.swift
//  APISqlite
//
//  Created by Drish on 08/09/20.
//  Copyright © 2020 Drish. All rights reserved.
//

import UIKit
import Reachability

class CommunicationManager: NSObject, URLSessionDelegate {
    var request :URLRequest!
    let reachabilityObj = Reachability()
    var isCreatedView = false
    var apiCallCount = 0
    
    
    
    func callSwitchPostMethod(urlStr:String,parameters:Data, _ completionHandler:@escaping ((_ response:Data,_ statusCode:Int) -> Void ),_ failure: @escaping ((_ error:Error? ,_ statusCode:Int?) -> Void ))
    {
        if BaseViewController().isInternetConnectivity(){
            
            let session = URLSession(configuration: URLSessionConfiguration.default,
                                     delegate: self,
                                     delegateQueue: nil)
            
            let url = urlStr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
            print(parameters)
            if (url?.count)! > 0
            {
                request = URLRequest(url: URL(string: url!)!)
                request.httpMethod = "POST"
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                
                request.httpBody = parameters
                request.timeoutInterval = 60.0
                do {
                    print(request)
                    let task = session.dataTask(with: request as URLRequest, completionHandler: {(data, response, error) in
                        
                        let statusCode = (response as? HTTPURLResponse)?.statusCode
                        if statusCode == 200 {
                            if data != nil {
                                completionHandler(data!,statusCode!)
                            }
                        }
                        else
                        {
                            if self.reachabilityObj?.connection == .none || self.reachabilityObj?.connection == .wifi || self.reachabilityObj?.connection == .cellular{
                                failure(error,nil)
                            }else{
                                self.callToNoInternetConnection()
                            }
                            print("Error is :\(String(describing: error))")
                        }
                    })
                    task.resume()
                }
            }
        }
    }
//    /////testing with multiple images
//    func callApiByMultiPartWithImages(urlStr:String,imageData: [Data],parameters:[String: AnyObject], _ completionHandler:@escaping ((_ response:Data,_ statusCode:Int) -> Void ),_ failure: @escaping ((_ error:Error? ,_ statusCode:Int?) -> Void ))
//    {
//        //        if ReachabilityManager.sharedInstance.isNetworkReachable()
//        //        {
//        let session = URLSession(configuration: URLSessionConfiguration.default, delegate: self, delegateQueue: nil)
//
//        request             = URLRequest(url: URL(string: urlStr)!)
//        request.httpMethod  = "POST"
//        let boundary        = "Boundary-\(UUID().uuidString)"
//
////        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
//        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
//
//        self.request.httpBody = createBodyWithMultipleImages(parameters: parameters, boundary: boundary, data: imageData , mimeType:
//            "image/jpg", filename: "")
//
//        do
//        {
//            let task = session.dataTask(with: request as URLRequest, completionHandler: {(data, response, error) in
//
//                let statusCode = (response as? HTTPURLResponse)?.statusCode
//                if statusCode == successCode.success
//                {
//                    if data != nil
//                    {
//                        completionHandler(data!,statusCode!)
//                    }
//                }else if statusCode == successCode.createdSuccess{
//                    if data != nil
//                    {
//                        completionHandler(data!,statusCode!)
//                    }
//                }
//                else
//                {
//                    completionHandler(data!,statusCode!)
//                    print("Error is :\(String(describing: error))")
//                }
//            })
//            task.resume()
//        }
//    }
//
    func createBodyWithMultipleImages(parameters: [String: AnyObject], boundary: String, data: [Data], mimeType: String, filename: String) -> Data
        {
           /* let body = NSMutableData()
            let boundaryPrefix = "--\(boundary)\r\n"
//

            if parameters != nil {
                body.appendString(boundaryPrefix)
                body.appendString("Content-Disposition: form-data; name=\"json\"\r\n\r\n")
                 
                for (key, value) in parameters {
                    
                    if key == "params"{
                        body.appendString(boundaryPrefix)
                        body.appendString("Content-Disposition: form-data; name=\"params\"\r\n\r\n")
                        if let temp = parameters["params"] as? NSDictionary{
                            for (key, value) in temp{
                                body.appendString(boundaryPrefix)
                                body.appendString("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n")
                                body.appendString("\(value)\r\n")
                            }
                        }
                      body.appendString("\r\n")
                    }
                    else{
                            body.appendString(boundaryPrefix)
                            body.appendString("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n")
                            body.appendString("\(value)\r\n")
                    }

              
                }
               body.appendString("\r\n")
                 if data.count > 0{
                    for i in 0..<data.count{
                        body.appendString(boundaryPrefix)
                        body.appendString("Content-Disposition: form-data; name=\"photo\"; filename=\"file\(i).jpg\"\r\n")
                        body.appendString("Content-Type: \(mimeType)\r\n\r\n")
                        body.append(data[i])
                        body.appendString("\r\n")
                    }
                }else{
    
    
                }
                
            }
            body.appendString("--".appending(boundary.appending("--")))
            request.setValue("\(body.length)", forHTTPHeaderField: "Content-Length")
            return body as Data*/
            
          /*  let body = NSMutableData()
                  let boundaryPrefix = "--\(boundary)\r\n"
                  
                  do {
                      let jsonData: Data = try JSONSerialization.data(withJSONObject: parameters, options: []) as Data
                      
                      
                      body.appendString(boundaryPrefix)
                      body.appendString("Content-Disposition: form-data; name=\"json\"\r\n\r\n")
                      body.appendString("\(jsonData.toString())\r\n")
                    
                   
                      
                      if data.count > 0{
                          for i in 0..<data.count{
                              body.appendString(boundaryPrefix)
                              body.appendString("Content-Disposition: form-data; name=\"photo\"; filename=\"file\(i).jpg\"\r\n")
                              body.appendString("Content-Type: \(mimeType)\r\n\r\n")
                              body.append(data[i])
                              body.appendString("\r\n")
                          }
                      }
                  } catch {}
                  
                
                  body.appendString("--".appending(boundary.appending("--")))
                  
                  request.setValue("\(body.length)", forHTTPHeaderField: "Content-Length")
                  return body as Data*/
            ///
            
           let body = NSMutableData()
            let boundaryPrefix = "--\(boundary)\r\n"

            print(parameters)

            let tempDict = NSMutableDictionary()
            tempDict.setValue(parameters, forKey: "json")

            for (key, value) in tempDict
            {
            print(key)
            print(value)

            do{
            let jsonData: Data = try JSONSerialization.data(withJSONObject: value, options: .prettyPrinted) as Data
            let str = String(data: jsonData, encoding: .utf8)
            print(str!)

            body.appendString(boundaryPrefix)
            body.appendString("Content-Disposition: form-data; name=\"json\"\r\n\r\n")
            body.appendString("\(str!)\r\n")

            if data.count > 0{
            for i in 0..<data.count{

            let filename = "image\(i+1).jpg"
            let key1 = "file\(i+1)"

            body.appendString(boundaryPrefix)
            body.appendString("Content-Disposition: form-data; name=\"\(key1)\"; filename=\"\(filename)\"\r\n")
            body.appendString("Content-Type: \(mimeType)\r\n\r\n")
            body.append(data[i])
            body.appendString("\r\n")
            }
            }
            }
            catch {}
            }

            body.appendString("--".appending(boundary.appending("--")))

            request.setValue("\(body.length)", forHTTPHeaderField: "Content-Length")
            return body as Data
            
        }
    
    
    
    func callApiByPostMethod(urlStr:String, type: String, parameters:Data, _ completionHandler:@escaping ((_ response:Data,_ statusCode:Int) -> Void ),_ failure: @escaping ((_ error:Error? ,_ statusCode:Int?) -> Void ))
    {
        if BaseViewController().isInternetConnectivity(){
           
            let session = URLSession(configuration: URLSessionConfiguration.default,
                                     delegate: self,
                                     delegateQueue: nil)
            
            let url = urlStr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
            print(parameters)
            if (url?.count)! > 0
            {
                request = URLRequest(url: URL(string: url!)!)
                request.httpMethod = "POST"
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                
                request.httpBody = parameters
                request.timeoutInterval = 60.0
                do {
                    print(request)
                    let task = session.dataTask(with: request as URLRequest, completionHandler: {(data, response, error) in
                        
                        let statusCode = (response as? HTTPURLResponse)?.statusCode
                        if statusCode == 200 {
                            if data != nil || data?.count != 0{
                                if type == "Email"
                                {
                                    
                                }
                                else{
                                    if type == "Login"
                                    {
                                        
                                    }
                                    else{
                                        if let dict = self.convertIntoDictionary(responseData: data, type: type) as NSDictionary?
                                     {
                                        print(dict)
                                        let str = dict.value(forKey: "message") as? String
                                        if (str?.contains("disabled") ?? false) || dict.value(forKey: "shouldLogout") as? Int == 1
                                        {
                                           // self.callToAccountDisable(string: dict.value(forKey: "message") as! String, shouldLogout: (dict.value(forKey: "shouldLogout") as? Int)!, type: type)
                                        }
                                        }
                                        else
                                     {
                                        DispatchQueue.main.async {
                                           if var topController = UIApplication.shared.keyWindow?.rootViewController {
                                                while let presentedViewController = topController.presentedViewController {
                                                    topController = presentedViewController
                                                }
                                                
                                                let obj = BaseViewController()
                                                 if let view = UIApplication.shared.keyWindow?.subviews.last {
                                                       for vw in view.subviews {
                                                           if vw is UIActivityIndicatorView {
                                                               view.removeFromSuperview()
                                                           }
                                                       }
                                                   }
                                               
//                                                let universityName = USER_DEFAULTS.value(forKey: KEYS.School_NAME) as? String
//                                                obj.showAlert(VC: topController, title: universityName ?? "", message: String.init(format: "This site is not responding\n\n '%@'", (USER_DEFAULTS.value(forKey: KEYS.mobileApi) as? String)!) , actionButtons: [ALERT_BUTTONS.OK.uppercased()], completionHandler: { (response) in
//
//                                                })
                                            }
                                        }
                                            }
                                    }
                                }
                                completionHandler(data!,statusCode!)
                            }
                        }
                            else if (statusCode ?? 0 >= 500)
                        {
                                  DispatchQueue.main.async {
                                      if var topController = UIApplication.shared.keyWindow?.rootViewController {
                                          while let presentedViewController = topController.presentedViewController {
                                              topController = presentedViewController
                                          }
                                          
                                          let obj = BaseViewController()
                                          if let view = UIApplication.shared.keyWindow?.subviews.last {
                                              for vw in view.subviews {
                                                  if vw is UIActivityIndicatorView {
                                                      view.removeFromSuperview()
                                                  }
                                              }
                                          }
                                          
//                                          let universityName = USER_DEFAULTS.value(forKey: KEYS.School_NAME) as? String
//                                          obj.showAlert(VC: topController, title: universityName ?? "", message: "Some error occurred at the server-side, please try again after some time. If this issue persists please reach us at support@ed-admin.com" , actionButtons: [ALERT_BUTTONS.OK.uppercased()], completionHandler: { (response) in
//
//                                          })
                                      }
                                  }
                          }
                        else
                        {
                            if self.reachabilityObj?.connection == .none || self.reachabilityObj?.connection == .wifi || self.reachabilityObj?.connection == .cellular{
                                failure(error,nil)
                            }else{
                                self.callToNoInternetConnection()
                            }
                            print("Error is :\(String(describing: error))")
                        }
                    })
                    task.resume()
                }
            }
        }else{
            
            self.callToNoInternetConnection()
            
        }
    }
    func callApiByGetMethod(urlStr:String, _ completionHandler:@escaping ((_ response:Data,_ statusCode:Int) -> Void ),_ failure: @escaping ((_ error:Error? ,_ statusCode:Int) -> Void ))
    {
        if reachabilityObj?.connection == .none || reachabilityObj?.connection == .wifi || reachabilityObj?.connection == .cellular{
            let session = URLSession(configuration: URLSessionConfiguration.default,
                                     delegate: self,
                                     delegateQueue: nil)
            let url = urlStr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
            request = URLRequest(url: URL(string: url!)!)
            request.httpMethod = "GET"
            
            request.timeoutInterval = 60.0
            do{
                print(request)
                let task = session.dataTask(with: request as URLRequest, completionHandler: {(data, response, error) in
                    if  error == nil
                    {
                        if data != nil{
                            completionHandler(data!,200)
                        }
                    }
                    else
                    {
                        if self.reachabilityObj?.connection == .none || self.reachabilityObj?.connection == .wifi || self.reachabilityObj?.connection == .cellular{
                            failure(error,404)
                        }else{
                            self.callToNoInternetConnection()
                        }
                        
                        print("Error is :\(String(describing: error))")
                    }
                    
                })
                task.resume()
            }
        }
        else{
            self.callToNoInternetConnection()
        }
    }
    
    
    func callToNoInternetConnection () {
        if var topController = UIApplication.shared.keyWindow?.rootViewController {
            while let presentedViewController = topController.presentedViewController {
                topController = presentedViewController
                
            }
            
            let obj = BaseViewController()
            if let view = UIApplication.shared.keyWindow?.subviews.last {
                for vw in view.subviews {
                    if vw is UIActivityIndicatorView {
                        view.removeFromSuperview()
                    }
                }
            }
//            let universityName = USER_DEFAULTS.value(forKey: KEYS.School_NAME) as? String
//            obj.showAlert(VC: topController, title: universityName ?? "", message: ERRORS.INTERNET_CONNECTIVITY , actionButtons: [ALERT_BUTTONS.OK.uppercased()], completionHandler: { (response) in
//
//            })
        }
    }
    
//    func callApiByMultiPart(urlStr:String,imageData: [Data],parameters:[String: AnyObject], jsonString: String ,_ completionHandler:@escaping ((_ response:Data,_ statusCode:Int) -> Void ),_ failure: @escaping ((_ error:Error? ,_ statusCode:Int?) -> Void ))
//    {
//        //        if ReachabilityManager.sharedInstance.isNetworkReachable()
//        //        {
//        let session = URLSession(configuration: URLSessionConfiguration.default, delegate: self, delegateQueue: nil)
//
//        request             = URLRequest(url: URL(string: urlStr)!)
//        request.httpMethod  = "POST"
//        let boundary        = "Boundary-\(UUID().uuidString)"
//
//        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
//
//        self.request.httpBody = createBody(parameters: parameters, boundary: boundary, data: imageData, jsonString: jsonString , mimeType:
//            "image/jpg", filename: "")
//
//        //        if let stringToken = UserDefaults.standard .value(forKey: AccessToken)
//        //        {
//        //            request.setValue(String.init(format: "Bearer %@", stringToken as! CVarArg) , forHTTPHeaderField: "Authorization")
//        //        }
//        //        do
//        //        {
//        let task = session.dataTask(with: request as URLRequest, completionHandler: {(data, response, error) in
//
//            let statusCode = (response as? HTTPURLResponse)?.statusCode
//            if statusCode == successCode.success
//            {
//                if data != nil
//                {
//                    completionHandler(data!,statusCode!)
//                }
//            }else if statusCode == successCode.createdSuccess{
//                if data != nil
//                {
//                    completionHandler(data!,statusCode!)
//                }
//            }
//            else
//            {
//                if data != nil{
//                    completionHandler(data!,statusCode ?? 400)
//                }
//                print("Error is :\(String(describing: error))")
//            }
//        })
//        task.resume()
//        //        }
//    }
    //---------------  create body of multipart data ------------
    
    
    func createBody(parameters: [String: AnyObject], boundary: String, data: [Data],jsonString : String , mimeType: String, filename: String) -> Data
    {
        let body = NSMutableData()
        let boundaryPrefix = "--\(boundary)\r\n"
        
        do {
            
            //        let jsonData: Data = try JSONSerialization.data(withJSONObject: parameters, options: []) as Data
//                       body.appendString(boundaryPrefix)
//                       body.appendString("Content-Disposition: form-data; name=\"json\"\r\n\r\n")
//                       body.appendString("\(jsonData.toString())\r\n")
            
            body.appendString(boundaryPrefix)
            body.appendString("Content-Disposition: form-data; name=\"json\"\r\n\r\n")
            body.appendString("\(jsonString)\r\n")
            
            
            if data.count > 0{
                for i in 0..<data.count{
                    body.appendString(boundaryPrefix)
                    body.appendString("Content-Disposition: form-data; name=\"photo\"; filename=\"image\(i).jpg\"\r\n")
                    body.appendString("Content-Type: \(mimeType)\r\n\r\n")
                    
                    body.append(data[i])
                    body.appendString("\r\n")
                }
            }
        }
        catch {}
       
        body.appendString("--".appending(boundary.appending("--")))
        request.setValue("\(body.length)", forHTTPHeaderField: "Content-Length")
        return body as Data
    }

    
//      func callToAccountDisable (string : String, shouldLogout: Int, type: String) {
//
//          DispatchQueue.main.async {
//              if var topController = UIApplication.shared.keyWindow?.rootViewController {
//                  while let presentedViewController = topController.presentedViewController {
//                      topController = presentedViewController
//                  }
//
//                  let obj = BaseViewController()
//                  if let view = UIApplication.shared.keyWindow?.subviews.last {
//                      for vw in view.subviews {
//                          if vw is UIActivityIndicatorView {
//                              view.removeFromSuperview()
//                          }
//                      }
//                  }
//                  if shouldLogout == 1
//                  {
//                      if type == "LeftMenu"
//                      {
//                          var multiActivationArray = (UserDefaults.standard.array(forKey: "MultiActivationArray") as? [[String: Any]])!
//
////                          let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
////                          let viewController: UIViewController = storyBoard.instantiateViewController(withIdentifier: STORYBOARD_ID.LOGIN_VC_ID)
//
////                          for items in multiActivationArray.indices
////                          {
////                              let obj = BaseViewController().readUserDefaultData()
////                              if obj.licenseName == multiActivationArray [items][KEYS.liesenceName] as? String
////                              {
////                                  multiActivationArray[items]["SelectedID"] = ""
////
////                                multiActivationArray[items]["SelectedUser"] = 0
////
////                                multiActivationArray[items][KEYS.IsLoggedIn] = ""
////                                  multiActivationArray[items][KEYS.ISAccountActivated] = "No"
////                                  print(multiActivationArray)
////                                  USER_DEFAULTS.set(multiActivationArray, forKey: KEYS.MultiActivationArray)
////                                  //                USER_DEFAULTS.synchronize()
////                              }
////                          }
//
//
////                          USER_DEFAULTS.set("", forKey: KEYS.LOGGED_IN)
////                          USER_DEFAULTS.removeObject(forKey: calendar_DATE)
////                          USER_DEFAULTS.removeObject(forKey: calendar_kEYRECORDS)
////                          USER_DEFAULTS.synchronize()
////                          APP_DELEGATE.window?.rootViewController    = viewController
////                          APP_DELEGATE.window?.makeKeyAndVisible()
//                    //    let navigationController = UINavigationController(rootViewController: viewController)
//                     //   let appdelegate = UIApplication.shared.delegate as! AppDelegate
//                     //   appdelegate.window!.rootViewController = navigationController
//                      }
//                      else{
//                          let universityName = USER_DEFAULTS.value(forKey: KEYS.School_NAME) as? String
//                          obj.showAlert(VC: topController, title: universityName ?? "", message: string, actionButtons: [ALERT_BUTTONS.OK.uppercased()], completionHandler: { (response) in
//
//                              var multiActivationArray = (UserDefaults.standard.array(forKey: "MultiActivationArray") as? [[String: Any]])!
//
////                              let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
////                              let viewController: UIViewController = storyBoard.instantiateViewController(withIdentifier: STORYBOARD_ID.LOGIN_VC_ID)
//
////                              for items in multiActivationArray.indices
////                              {
////                                  let obj = BaseViewController().readUserDefaultData()
////                                  if obj.licenseName == multiActivationArray [items][KEYS.liesenceName] as? String
////                                  {
////                                     multiActivationArray[items]["SelectedID"] = ""
////
////                                    multiActivationArray[items]["SelectedUser"] = 0
////
////
////                                    multiActivationArray[items][KEYS.IsLoggedIn] = ""
////                                      multiActivationArray[items][KEYS.ISAccountActivated] = "No"
////                                      print(multiActivationArray)
////                                      USER_DEFAULTS.set(multiActivationArray, forKey: KEYS.MultiActivationArray)
////                                      //                USER_DEFAULTS.synchronize()
////                                  }
////                              }
//
//
//                              USER_DEFAULTS.set("", forKey: KEYS.LOGGED_IN)
//                              USER_DEFAULTS.removeObject(forKey: calendar_DATE)
//                              USER_DEFAULTS.removeObject(forKey: calendar_kEYRECORDS)
//                              USER_DEFAULTS.synchronize()
////                            let navigationController = UINavigationController(rootViewController: viewController)
////                            let appdelegate = UIApplication.shared.delegate as! AppDelegate
////                            appdelegate.window!.rootViewController = navigationController
////                              APP_DELEGATE.window?.rootViewController    = viewController
////                              APP_DELEGATE.window?.makeKeyAndVisible()
//
//                          })
//                      }
//
//                  }
//                  else{
//                  let universityName = USER_DEFAULTS.value(forKey: KEYS.School_NAME) as? String
//                  obj.showAlert(VC: topController, title: universityName ?? "", message: string, actionButtons: [ALERT_BUTTONS.OK.uppercased()], completionHandler: { (response) in
//
//                      var multiActivationArray = (UserDefaults.standard.array(forKey: "MultiActivationArray") as? [[String: Any]])!
//
////                      let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
////                      let viewController: UIViewController = storyBoard.instantiateViewController(withIdentifier: STORYBOARD_ID.LOGIN_VC_ID)
//
////                      for items in multiActivationArray.indices
////                      {
////                          let obj = BaseViewController().readUserDefaultData()
////                          if obj.licenseName == multiActivationArray [items][KEYS.liesenceName] as? String
////                          {
////                              multiActivationArray[items][KEYS.IsLoggedIn] = ""
////                              multiActivationArray[items][KEYS.ISAccountActivated] = "No"
////                              print(multiActivationArray)
////                              USER_DEFAULTS.set(multiActivationArray, forKey: KEYS.MultiActivationArray)
////                              //                USER_DEFAULTS.synchronize()
////                          }
////                      }
//
//
//                      USER_DEFAULTS.set("", forKey: KEYS.LOGGED_IN)
//                      USER_DEFAULTS.removeObject(forKey: calendar_DATE)
//                      USER_DEFAULTS.removeObject(forKey: calendar_kEYRECORDS)
//                      USER_DEFAULTS.synchronize()
////                      APP_DELEGATE.window?.rootViewController    = viewController
////                      APP_DELEGATE.window?.makeKeyAndVisible()
////                    let navigationController = UINavigationController(rootViewController: viewController)
////                    let appdelegate = UIApplication.shared.delegate as! AppDelegate
////                    appdelegate.window!.rootViewController = navigationController
//
//                  })
//                  }
//              }
//          }
//
//      }
    func convertIntoDictionary(responseData: Data?, type: String) -> [String:AnyObject]? {
        if responseData != nil{
            do {
                let datastring = NSString(data: responseData!, encoding: String.Encoding.isoLatin1.rawValue)
                let data = datastring!.data(using: String.Encoding.utf8.rawValue)
                if USER_DEFAULTS.value(forKey: "FinanceValue") as? Bool == true || USER_DEFAULTS.value(forKey: "NotificationValue") as? Bool == true
                {
                    USER_DEFAULTS.set(false, forKey: "FinanceValue")
                    USER_DEFAULTS.set(false, forKey: "NotificationValue")
                    USER_DEFAULTS.synchronize()
                    return try JSONSerialization.jsonObject(with: responseData!, options: .allowFragments) as? [String:AnyObject]
                             }
                else{
                return try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String:AnyObject]
                }
            }catch{
                print(error.localizedDescription)
            }
        }
        return nil
    }
}
extension NSMutableData
{
    func appendString(_ string: String) {
        let data = string.data(using: String.Encoding.utf8, allowLossyConversion: false)
        append(data!)
    }
}

extension Data{
    func toString() -> String { return String(data: self, encoding: .utf8)! }
}
