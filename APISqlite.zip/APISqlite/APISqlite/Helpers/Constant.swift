//
//  Constant.swift
//  APISqlite
//
//  Created by Drish on 08/09/20.
//  Copyright © 2020 Drish. All rights reserved.
//

import Foundation
import UIKit
 
let Certificate_URL = "http://supertekglassware.com/wp-content/uploads/2020/06/Calibration-Certificate-Download-Guide.pdf"
 let Doc_Name = "Calibration-Certificate-Guide.pdf"
let Base_URL = "http://supertekglassware.com/certificate-api/certificate/"
//let Base_URL = "http://supertek.drishinfo.com/certificate-api/certificate/"
let Batch_URL = "batchCertificate.php"
let Individual_URL = "individualCertificate.php"
let APP_TITLE =  "Employee"
@available(iOS 13.0, *)
let APP_DELEGATE = UIApplication.shared.delegate as! AppDelegate
let USER_DEFAULTS = UserDefaults.standard
let fillCatalogueNo = "Please Fill Catalogue No."
let fillBatchNo = "Please Fill Batch No."
let fillIndividualNO = "Please Fill Individual No."
struct ERRORS {
    static let INTERNET_CONNECTIVITY = "Internet access required."
}
struct ALERT_BUTTONS {
    static let OK = "Ok"
    static let CANCEL = "Cancel"
    static let GotoAppstore = "Go to Appstore"
    
    
}
