//
//  AddEmpVC.swift
//  APISqlite
//
//  Created by Drish on 08/09/20.
//  Copyright © 2020 Drish. All rights reserved.
//

import UIKit
class AddEmpVC: BaseViewController {
    @IBOutlet weak var txtFirstName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtLastName: UITextField!
    var empObj = EmployeeModal()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func btnAddEmp(_ sender: Any) {
//        if BaseViewController().isInternetConnectivity()
//        {
//            if(txtFirstName.text == ""){
//             self.showAlert(VC: self, title: APP_TITLE, message: "Enter First Name" , actionButtons: ["Ok"], completionHandler: { (success) in
//                                                                  })
//            }
//            else if( txtLastName.text! == ""){
//             self.showAlert(VC: self, title: APP_TITLE, message: "Enter Last Name" , actionButtons: ["Ok"], completionHandler: { (success) in
//               })
//            }
//            else if( txtEmail.text! == ""){
//             self.showAlert(VC: self, title: APP_TITLE, message: "Enter Email", actionButtons: ["Ok"], completionHandler: { (success) in
//                    })
//            }
//            else {
//                    self.createActivityIndicatorView(viewController: self)
//                    let webServiceObj = WebServices()
//                    empObj.email = txtEmail.text
//                    empObj.firstName = txtFirstName.text
//                    empObj.lastName = txtLastName.text
//                    webServiceObj.addEmployee( obj: empObj) { (response, error, success) in
//                    DispatchQueue.main.async
//                    {
//                        self.removeActivityIndicatorView()
//                        var data = response
//                        let viewController = self.storyboard!.instantiateViewController(withIdentifier: "empDetailVC") as! EmpDetailVC
//                        self.empObj.email = response?.email
//                       self.empObj.firstName = response?.firstName
//                       self.empObj.lastName = response?.lastName
//                     //   viewController.empObj = self.empObj
//                        self.navigationController!.pushViewController(viewController, animated: true)
////                        let viewController = self.storyboard?.instantiateViewController(withIdentifier: "AlertVC") as! EmpDetailVC
////                        viewController.modalPresentationStyle = .overFullScreen
////                        self.empObj.email = response?.email
////                        self.empObj.firstName = response?.firstName
////                        self.empObj.lastName = response?.lastName
////                        viewController.empObj = self.empObj
////                        self.present(viewController, animated: true, completion: nil)
//                    }
//                  
//                }
//             }
//           }
//            else{
//                       self.showAlert(VC: self, title: APP_TITLE, message: ERRORS.INTERNET_CONNECTIVITY, actionButtons: ["Ok"], completionHandler: { (success) in
//                          })
//                  }
        }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
