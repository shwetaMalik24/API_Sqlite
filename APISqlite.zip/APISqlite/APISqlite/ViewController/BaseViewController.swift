//
//  BaseViewController.swift
//  APISqlite
//
//  Created by Drish on 08/09/20.
//  Copyright © 2020 Drish. All rights reserved.
//

import UIKit
import Reachability

class BaseViewController: UIViewController
{
    var activityIndicator : UIActivityIndicatorView?
    var activityIndicatorBGView : UIView?
    let reachabilityObj = Reachability()
    var noInternetView : UIView?
    var vc : UIViewController?
    
    let startUpListArray = ["News", "Notification", "My Profile", "Calendar", "My Students", "Documents", "Finance", "Directory", "Updates", "Settings"]
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()     // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    
//    //MARK: -- Textfields Validation Methods
//    func validateFields(textField : String, value: String) -> String {
//        var errorStr = ""
//        if textField == TEXTFIELD.tokenNumberTF.rawValue {
//            if value.isEmpty{
//                errorStr = ERRORS.EMPTY_EMAIL
//                return errorStr
//            }
//        }else if textField == TEXTFIELD.passwordTF.rawValue {
//            if value.isEmpty {
//                errorStr = ERRORS.EMPTY_PASSWORD
//                return errorStr
//            }
//        }
//        return errorStr
//    }
    func isInternetConnectivity() -> Bool {
        if reachabilityObj?.connection == .none || reachabilityObj?.connection == .wifi || reachabilityObj?.connection == .cellular{
            return true
        }else{
            return false
        }
    }
    func trimSpecialChar(_ inputStr: String?) -> String? {
        var fileName = inputStr
        let doNotWant = CharacterSet(charactersIn: "#%;:?,|[]{}@$%^*")
        fileName = fileName?.components(separatedBy: doNotWant).joined(separator: "")
        print("\(fileName ?? "")")
        print("Result: \(fileName ?? "")")
        return fileName
    }
    
    //MARK: -- Alert View Validation Methods
    func showAlert(VC: UIViewController, title: String, message: String, actionButtons : Array<String>, completionHandler: @escaping (_ response: String) -> Void) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        for buttonTitle in actionButtons {
            if buttonTitle == actionButtons[0]{
                let action = UIAlertAction(title: buttonTitle , style: .cancel, handler: { (action:UIAlertAction!) in
                    completionHandler(action.title!)
                })
                alert.addAction(action)
            }else{
                
                let action = UIAlertAction(title: buttonTitle , style: .default, handler: {(action:UIAlertAction!) in
                    
                    completionHandler(action.title!)
                })
                alert.addAction(action)
            }
        }
        DispatchQueue.main.async {
                  VC.present(alert, animated: true, completion: nil)
              }
    }
    
   
    func createActivityIndicatorView(viewController: UIViewController) {
        activityIndicatorBGView = UIView(frame: CGRect.init(x: 0.0, y: 0.0 , width:(viewController.view.layer.bounds.width), height: viewController.view.layer.bounds.height))
        vc = viewController
        activityIndicatorBGView!.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        activityIndicatorBGView!.tag = 100
        //activityIndicatorBGView?.tag = 10
        activityIndicator = UIActivityIndicatorView()
       // let transform = CGAffineTransform(scaleX: 1.5, y: 1.5)
        //activityIndicator?.transform = transform
        activityIndicator?.center = (activityIndicatorBGView?.center)!
        activityIndicator?.hidesWhenStopped = true
        activityIndicator?.color = UIColor.black
        activityIndicatorBGView?.addSubview(activityIndicator!)
        if #available(iOS 13.0, *) {
            viewController.view.addSubview(activityIndicatorBGView!)
            APP_DELEGATE.window?.addSubview(activityIndicatorBGView!)
        } else {
            viewController.view.addSubview(activityIndicatorBGView!)
            //APP_DELEGATE.window?.addSubview(activityIndicatorBGView!)
        }
        activityIndicator?.startAnimating()
    }
    @available(iOS 13.0, *)
    func createCalendarIndicatorView(viewController: UIViewController) {
        DispatchQueue.main.async {
            self.activityIndicatorBGView = UIView(frame: CGRect.init(x: 0.0, y: 0.0 , width:(APP_DELEGATE.window?.bounds.width)!, height: (APP_DELEGATE.window?.bounds.height)!))
            self.activityIndicatorBGView?.tag = 10
            self.activityIndicator = UIActivityIndicatorView()
            let transform = CGAffineTransform(scaleX: 1.5, y: 1.5)
            self.activityIndicator?.transform = transform
            self.activityIndicator?.center = (self.activityIndicatorBGView?.center)!
            self.activityIndicator?.hidesWhenStopped = true
            self.activityIndicator?.color = UIColor.black
            self.activityIndicatorBGView?.addSubview(self.activityIndicator!)
            APP_DELEGATE.window?.addSubview(self.activityIndicatorBGView!)
            self.activityIndicator?.startAnimating()
        }
       }
    func removeActivityIndicatorView() {
        //activityIndicatorBGView?.isHidden = true
        //activityIndicatorBGView?.removeFromSuperview()
        if let viewWithTag = self.view.viewWithTag(100) {
               viewWithTag.removeFromSuperview()
        }
    }
    //Mark: UserDefaults methods
    
//    func saveUserDefaultsData(obj : ActivationModel)
//    {
//        let data = NSKeyedArchiver.archivedData(withRootObject: obj)
//        USER_DEFAULTS.set(data, forKey: KEYS.USERDATA)
//        USER_DEFAULTS.synchronize()
//    }
    
    
    // Validation For Mobile
    func phoneNumberValidation(_ value: String) -> Bool {
        let charset : String =  "0123456789,;( )+-"
        for item in value {
            if(charset.contains(item))
            {
                continue
            }
            else
            {
                return false
            }
        }
        return true
        /* let phone_regex = "(\\+?)[0-9](\\d{8,16})*$"
         let phoneTest = NSPredicate(format: "SELF MATCHES %@",phone_regex)
         return phoneTest.evaluate(with: value) */
        /* let phone_regex = try! NSRegularExpression(pattern: "^(\\+?6?01)[0|1|2|3|4|6|7|8|9]\\-*[0-9]{7,8}$/", options: .caseInsensitive)
         let phoneTest  = NSPredicate(format:"SELF MATCHES %@", phone_regex)
         return phoneTest.evaluate(with: value) */
    }
    func getTodayString(date: String?) -> String{
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd HH:mm:ss"
        let newFormatter = DateFormatter()
        newFormatter.dateFormat =  "EEEE, MMM d, H:mm"
        if let date = formatter.date(from: date!) {
            print(newFormatter.string(from: date))
            let dateStr = newFormatter.string(from: date)
            var pointsArr = dateStr.components(separatedBy: ",")
            let day = pointsArr[0].prefix(3)
            let month = pointsArr[1]
            let time = pointsArr[2]
            
            let today_string = String(day) + "" + String(month) + "" + String(time)
            
            return today_string
            
        } else {
            print("There was an error decoding the string")
        }
        return ""
    }
    func changeDateFormat(date: String?) -> String{
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd"
        
        let newFormatter = DateFormatter()
        newFormatter.dateFormat =  "EEEE, MMM d, H:mm"
        
        if let date = formatter.date(from: date!) {
            print(newFormatter.string(from: date))
            let dateStr = newFormatter.string(from: date)
            var pointsArr = dateStr.components(separatedBy: ",")
            let day = pointsArr[0].prefix(3)
            let month = pointsArr[1]
            let time = pointsArr[2]
            
            let today_string = String(day) + "" + String(month)
            
            return today_string
            
        } else {
            print("There was an error decoding the string")
        }
        return ""
    }
    
//    @objc func readUserDefaultData() -> ActivationModel
//    {
//        let userModelObj: ActivationModel = NSKeyedUnarchiver.unarchiveObject(with: USER_DEFAULTS.value(forKey: KEYS.USERDATA) as! Data) as! ActivationModel
//
//        return userModelObj
//    }
//    func removeUserDefaultData()
//    {
//        USER_DEFAULTS.removeObject(forKey:KEYS.USERDATA)
//    }
    func getImageFromUrl(urlStr: String?) -> UIImage? {
        var image: UIImage? = nil
        let url = URL(string: urlStr!)
        do{
            let data = try Data(contentsOf: url!)
            image = UIImage(data: data)
        }catch{
            print("error")
        }
        return image
    }
    
//    func getCurrentViewController(){
//        let array = APP_DELEGATE.window?.rootViewController?.children
//        if array!.count > 0
//        {
//        let vc = array![(array?.count)! - 1]
//        APP_DELEGATE.currentVCIdentifier = vc.restorationIdentifier
//        }
//    }
    
    // MARK :-  Open Link
    func openLink(link: String)
    {
        let result: Bool = link.lowercased().hasPrefix("https://")
        if result {
            UIApplication.shared.openURL(URL(string: link)!)
        }
        else {
            let urlString = "https://\(link)"
            UIApplication.shared.openURL(URL(string: urlString)!)
        }
    }
    
    // MARK :- Send Mail SharedURL
    
    func noInternetConnectionView(view : UITableView?) -> UIView {
        if let height = view?.tableHeaderView?.frame.size.height  {
            
        }
        let lbl = UILabel(frame: CGRect(x: 0, y: 40, width: self.view.frame.size.width, height: 30))
        lbl.text = ERRORS.INTERNET_CONNECTIVITY
        lbl.textColor = UIColor.black
        lbl.textAlignment = .center
        noInternetView?.tag = 1001
        noInternetView?.addSubview(lbl)
        return noInternetView!
    }
    
    func removeNoInternetConnectionView(superView: UIView) {
        for vws in superView.subviews {
            if vws.tag == 1001 {
                vws.removeFromSuperview()
            }
        }
    }
    func convertDateString(dateString : String!, fromFormat sourceFormat : String!, toFormat desFormat : String!) -> String {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = sourceFormat
        let date = dateFormatter.date(from: dateString)
        
        dateFormatter.dateFormat = ""
        
        return dateFormatter.string(from: date!)
    }
    
    func removeAllActivityIndicatorView() {
        
        let SubArray : Array = self.view.window?.subviews ?? []
        
        for item in SubArray {
            
            let dummyView : UIView = item
            if dummyView.tag == 10
            {
                dummyView.removeFromSuperview()
            }
        }
    }
}
