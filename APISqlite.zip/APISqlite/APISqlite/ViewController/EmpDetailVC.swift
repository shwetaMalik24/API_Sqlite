//
//  EmpDetailVC.swift
//  APISqlite
//
//  Created by Drish on 08/09/20.
//  Copyright © 2020 Drish. All rights reserved.
//

import UIKit
import SDWebImage
class EmpDetailVC: BaseViewController, UITableViewDelegate , UITableViewDataSource  {
  var db:DBHelper = DBHelper()
   var employeeAge : Int!
    var employeeName : String!
    var employeeSalary : Int!
    var id : Int!
    var profileImage : String!
    var fetchedEmp = [EmployeeDB]()
    @IBOutlet weak var tableView: UITableView!
    let serialQueue = DispatchQueue(label: "com.queue.serial")
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchFromInternet()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        _ = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(fireTimer), userInfo: nil, repeats: true)
    }
    @objc func fireTimer() {
        print("timer fired")
        serialQueue.sync  {
          self.fetchFromInternet()
            print("in api")
        }
       print("out side api")
    }
 //Delegates
 func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return fetchedEmp.count
 }

 func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! EmployeeCell
    cell.lblEmpName.text = fetchedEmp[indexPath.row].employee_name as String
    let url = URL(string: fetchedEmp[indexPath.row].profile_image as String)
    let urlString = URL.init(string: fetchedEmp[indexPath.row].profile_image as String)
 cell.imgEmp.sd_setImage(with:urlString , placeholderImage: nil)
    DispatchQueue.global().async {
        let data = try? Data(contentsOf: url!)
       // cell.imgEmp.image = UIImage(data: data!)
      // cell.imgEmp.sd_setImage(with: url)
      
           //cell.imgEmp.sd_setImage(with:urlString , placeholderImage: nil)
//        DispatchQueue.main.async
//            {
//
//                 //cell.imgEmp.sd_setImage(with:urlString , placeholderImage: nil)
//           cell.imgEmp.image = UIImage(data: data!)
//        }
    }
    //cell.lblEmpSalary.text = String(fetchedEmp[indexPath.row].employee_salary)
     return cell
 }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80;//Choose your custom row height
    }
    func fetchFromInternet(){
           if BaseViewController().isInternetConnectivity()
                {
                            self.createActivityIndicatorView(viewController: self)
                            let webServiceObj = WebServices()
                            let empObj = EmployeeModal()
                            webServiceObj.getEmployees(obj: empObj) { (response, error, success, statusCode) in
                            DispatchQueue.main.async
                            {
                                let data = response
                                for item in data!.empData
                                      {
                                        self.employeeAge = item["employee_age"] as? Int
                                        self.employeeName = item["employee_name"] as? String
                                        self.employeeSalary = item["employee_salary"] as? Int
                                        self.id = item["id"] as? Int
                                        self.profileImage = item["profile_image"] as? String
                                        self.db.insert(id: Int32(Int(self.id)), employee_name: self.employeeName! as NSString, employee_salary: Int32(Int(self.employeeSalary))
                                            , profile_image: self.profileImage! as NSString, employee_age: Int32(self.employeeAge))
                                        self.fetchedEmp = self.db.read()
                                        self.fetchedEmp.reverse()
                                        self.tableView.reloadData()
                                      }
                            }
                        }
                        self.removeActivityIndicatorView()
                     }
                    else{
                               self.showAlert(VC: self, title: APP_TITLE, message: ERRORS.INTERNET_CONNECTIVITY, actionButtons: ["Ok"], completionHandler: { (success) in
                                  })
                          }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
