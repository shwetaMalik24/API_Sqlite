//
//  EmployeeModal.swift
//  APISqlite
//
//  Created by Drish on 09/09/20.
//  Copyright © 2020 Drish. All rights reserved.
//

import Foundation
class EmployeeModal : NSObject, NSCoding{
    var dict : NSDictionary!
    var empData = [NSDictionary]()
    var employeeAge : Int!
    var employeeName : String!
    var employeeSalary : Int!
    var id : Int!
    var profileImage : String!
    override init()
    {
        
    }
    required init(fromDictionary : NSArray){
        var data = fromDictionary
        for item in data
        {
             dict = item as! NSDictionary
            employeeAge = dict["employee_age"] as? Int
            employeeName = dict["employee_name"] as? String
            employeeSalary = dict["employee_salary"] as? Int
            id = dict["id"] as? Int
            profileImage = dict["profile_image"] as? String
            empData.append(item as! NSDictionary)
        }
       }
    func toDictionary() -> [String:Any]
    {
        var dictionary = [String:Any]()
        if employeeAge != nil{
            dictionary["employee_age"] = employeeAge
        }
        if employeeName != nil{
            dictionary["employee_name"] = employeeName
        }
        if employeeSalary != nil{
            dictionary["employee_salary"] = employeeSalary
        }
        if id != nil{
            dictionary["id"] = id
        }
        if profileImage != nil{
            dictionary["profile_image"] = profileImage
        }
        return dictionary
    }

    /**
     * NSCoding required initializer.
     * Fills the data from the passed decoder
     */
    @objc required init(coder aDecoder: NSCoder)
    {
        employeeAge = aDecoder.decodeObject(forKey: "employee_age") as? Int
        employeeName = aDecoder.decodeObject(forKey: "employee_name") as? String
        employeeSalary = aDecoder.decodeObject(forKey: "employee_salary") as? Int
        id = aDecoder.decodeObject(forKey: "id") as? Int
        profileImage = aDecoder.decodeObject(forKey: "profile_image") as? String
    }

    /**
     * NSCoding required method.
     * Encodes mode properties into the decoder
     */
    @objc func encode(with aCoder: NSCoder)
    {
        if employeeAge != nil{
            aCoder.encode(employeeAge, forKey: "employee_age")
        }
        if employeeName != nil{
            aCoder.encode(employeeName, forKey: "employee_name")
        }
        if employeeSalary != nil{
            aCoder.encode(employeeSalary, forKey: "employee_salary")
        }
        if id != nil{
            aCoder.encode(id, forKey: "id")
        }
        if profileImage != nil{
            aCoder.encode(profileImage, forKey: "profile_image")
        }
    }
}
