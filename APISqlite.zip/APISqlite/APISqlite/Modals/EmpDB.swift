//
//  EmpDB.swift
//  APISqlite
//
//  Created by Drish on 10/09/20.
//  Copyright © 2020 Drish. All rights reserved.
//

import Foundation
class EmployeeDB
{
    let id: Int64
    let employee_name: NSString
     let profile_image: NSString
    let employee_salary: Int64
     let employee_age: Int64
    init(id:Int64, employee_name:NSString, employee_salary:Int64, profile_image: NSString, employee_age: Int64)
    {
        self.id = id
        self.employee_name = employee_name
        self.employee_age = employee_age
        self.employee_salary = employee_salary
        self.profile_image = profile_image
    }
}
