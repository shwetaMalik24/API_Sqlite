//
//  DBHelper.swift
//  APISqlite
//
//  Created by Drish on 10/09/20.
//  Copyright © 2020 Drish. All rights reserved.
import Foundation
import SQLite3
class DBHelper
{
    init()
    {
        db = openDatabase()
        createTable()
    }
  //  let dbPath: String = "myDb.sqlite"
    let dbPath: String = "empDB.sqlite"
    var db:OpaquePointer?
    func openDatabase() -> OpaquePointer?
    {
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent(dbPath)
        print(fileURL)
        var db: OpaquePointer? = nil
        if sqlite3_open(fileURL.path, &db) != SQLITE_OK
        {
            print("error opening database")
            return nil
        }
        else
        {
            print("Successfully opened connection to database at \(dbPath)")
            return db
        }
    }
    func createTable() {
        let createTableString = "CREATE TABLE IF NOT EXISTS EmployeeDB(id INTEGER PRIMARY KEY,employee_name TEXT,employee_salary INTEGER ,profile_image TEXT, employee_age INTEGER);"
        var createTableStatement: OpaquePointer? = nil
        if sqlite3_prepare_v2(db, createTableString, -1, &createTableStatement, nil) == SQLITE_OK
        {
            if sqlite3_step(createTableStatement) == SQLITE_DONE
            {
              //  print("person table created.")
            } else {
             //   print("person table could not be created.")
            }
        } else {
           //print("CREATE TABLE statement could not be prepared.")
        }
        sqlite3_finalize(createTableStatement)
    }
    func insert(id:Int32, employee_name:NSString, employee_salary:Int32, profile_image: NSString, employee_age: Int32)
    {
        let persons = read()
        for p in persons
        {
            if p.id == id
            {
                return
            }
        }
        let insertStatementString = "INSERT INTO EmployeeDB(id, employee_name, employee_salary,profile_image,employee_age) VALUES (NULL, ?, ?, ? , ?);"
        var insertStatement: OpaquePointer? = nil
        var demo = sqlite3_prepare_v2(db, insertStatementString, -1, &insertStatement, nil) == SQLITE_OK
        if sqlite3_prepare_v2(db, insertStatementString, -1, &insertStatement, nil) == SQLITE_OK
        {
             sqlite3_bind_int(insertStatement, 0, Int32(id))
            sqlite3_bind_text(insertStatement, 1, (employee_name as NSString).utf8String, -1, nil)
            sqlite3_bind_int(insertStatement, 2, Int32(employee_salary))
            sqlite3_bind_text(insertStatement, 3, (profile_image as NSString).utf8String, -1, nil)
            sqlite3_bind_int(insertStatement, 4, Int32(employee_age))
            if sqlite3_step(insertStatement) == SQLITE_DONE
            {
              //  print("Successfully inserted row.")
            } else
            {
               // print("Could not insert row.")
            }
        } else {
           // print("INSERT statement could not be prepared.")
        }
        sqlite3_finalize(insertStatement)
    }
    func read() -> [EmployeeDB] {
        let queryStatementString = "SELECT * FROM EmployeeDB;"
        var queryStatement: OpaquePointer? = nil
        var psns : [EmployeeDB] = []
      if sqlite3_prepare_v2(db, queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            while sqlite3_step(queryStatement) == SQLITE_ROW {
                let id = sqlite3_column_int(queryStatement, 0)
                let name = String(describing: String(cString: sqlite3_column_text(queryStatement, 1)))
                let salary = sqlite3_column_int(queryStatement, 2)
                let image = String(describing: String(cString: sqlite3_column_text(queryStatement, 3)))
                let age = sqlite3_column_int(queryStatement, 4)
                psns.append(EmployeeDB(id: Int64(Int(id)), employee_name: name as NSString, employee_salary: Int64(Int(salary)), profile_image: image as NSString, employee_age: Int64(Int(age))))
               // print("Query Result:")
           }
        }
        else {
           // print("SELECT statement could not be prepared")
        }
        sqlite3_finalize(queryStatement)
        return psns
    }
    func deleteByID(id:Int32)-> Int
    {
        let deleteStatementStirng = "DELETE FROM person WHERE Id = ?;"
        var deleteStatement: OpaquePointer? = nil
        if sqlite3_prepare_v2(db, deleteStatementStirng, -1, &deleteStatement, nil) == SQLITE_OK {
            sqlite3_bind_int(deleteStatement, 1, Int32(id))
            if sqlite3_step(deleteStatement) == SQLITE_DONE {
                print("Successfully deleted row.")
                return 1
            } else {
                print("Could not delete row.")
            }
        }
        else
        {
            print("DELETE statement could not be prepared")
            
        }
        sqlite3_finalize(deleteStatement)
        return 0
    }
    
 
    func prepareStatement(sql: String) throws -> OpaquePointer? {
     var statement: OpaquePointer?
       if sqlite3_prepare_v2(db, sql, -1, &statement, nil) == SQLITE_OK {
           return statement
        }
        return statement
    }
    enum SQLiteError: Error
    {
      case OpenDatabase(message: String)
      case Prepare(message: String)
      case Step(message: String)
      case Bind(message: String)
    }
    func contact(id: Int32) -> EmployeeDB? {
      let querySql = "SELECT * FROM person WHERE Id = ?;"
      guard let queryStatement = try? prepareStatement(sql: querySql) else {
        return nil
      }
      defer {
        sqlite3_finalize(queryStatement)
      }
      guard sqlite3_bind_int(queryStatement, 1, id) == SQLITE_OK else {
        return nil
      }
      guard sqlite3_step(queryStatement) == SQLITE_ROW else {
        return nil
      }
      let id = sqlite3_column_int(queryStatement, 0)
      guard let queryResultCol1 = sqlite3_column_text(queryStatement, 1) else {
        print("Query result is nil.")
        return nil
      }
     
      let name = String(describing: String(cString: sqlite3_column_text(queryStatement, 1)))
      let image = String(describing: String(cString: sqlite3_column_text(queryStatement, 2)))
      let salary = sqlite3_column_int(queryStatement, 3)
      let age = sqlite3_column_int(queryStatement, 4)
        return EmployeeDB(id: Int64(Int(id)), employee_name: name as NSString, employee_salary: Int64(Int(salary)), profile_image: image as NSString, employee_age: Int64(Int(age)))
    }
    
    func update(name: NSString, id: Int32, age: Int32) -> Int {
     var updateStatement: OpaquePointer?
     let updateStatementString = "UPDATE person SET name = ? WHERE Id = ?;"
        sqlite3_bind_text(updateStatement, 1, (name as NSString).utf8String, -1, nil)
        sqlite3_bind_int(updateStatement, 2, Int32(id))
        if sqlite3_prepare_v2(db, updateStatementString, -1, &updateStatement, nil) == SQLITE_OK {
        if sqlite3_step(updateStatement) == SQLITE_DONE {
        sqlite3_finalize(updateStatement)
         print("\nSuccessfully updated row.")
         return 1
       } else {
         print("\nCould not update row.")
       }
     } else {
       print("\nUPDATE statement is not prepared")
     }
     sqlite3_finalize(updateStatement)
        return 0
   }
}
